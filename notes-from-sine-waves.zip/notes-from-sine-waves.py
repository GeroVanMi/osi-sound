import wave
import math
import sys
import json

printdebug = lambda s: None

if len(sys.argv) < 2:
    exit("Syntax: notes-from-sine-waves <wavfile>")

wavfile = sys.argv[1]

w = wave.open(wavfile)

ch = w.getnchannels()
re = w.getsampwidth()
width = (re * ch)

spectrum = 2 ** (re * 8)
zlinepre = spectrum // 2

s = w.getnframes() / w.getframerate()
print(f"Audio duration: {w.getnframes()} frames with {s} seconds")
print(f"Audio format: {w.getframerate()} Hz, {re*8} bit, {ch} channels")

#mindiff = 1000
#mindist = 20

blocksize = 2 ** 20
s = w.readframes(blocksize)
frames = len(s) // width
print(f"Audio reading: {blocksize:7} requested frames = {len(s):8} received bytes = {frames:7} received frames")

lastvalue = 0
lastzeropos = 0
lastnote = None
lastnotepos = 0
noteslist = []

for i in range(frames):
    vec = s[i * width:(i + 1) * width]
    if ch > 1:
        # use right channel, seems to be default on Linux audio capture but does not matter for synthesised files
        vec = vec[re:]
    value = vec[0]
    if re == 2:
        # combine two 8-bit amplitude values into one 16-bit amplitude
        value = vec[1] * 256 + vec[0]
    if value > zlinepre:
        # signed representation (curve around x axis) while wave module gives only unsigned
        value -= spectrum

    printdebug(f"READ: pos={i:6} val={value:5}")

    change = False
    if value >= 0 and lastvalue < 0:
        change = True
    lastvalue = value

    if change:
        distance = i - lastzeropos
        freq = 1 / (distance / w.getframerate())
        pitch = int(freq)
        pitch = (math.log(int(freq), 2) - math.log(440, 2)) * 12 + 9

        printdebug(f"WAVE: wavelen={distance:4} freq=~{int(freq):4} Hz")
        lastzeropos = i

        if abs(pitch - round(pitch)) < 0.2:
            rpitch = int(round(pitch))
            keytable = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "H"]
            note = keytable[rpitch % 12]
            octave = rpitch // 12
            if octave > 0:
                note += "+"
            elif octave < 0:
                note += "-"
            normfreq = round(440 * 2 ** ((rpitch - 9) / 12), 1)
            printdebug(f"NOTE partial: note=~{note:3} {normfreq:4} Hz @ {i:7}")
        else:
            note = None

        if note != lastnote:
            if lastnote is not None:
                # FIXME: the factor 2 is not quite clear...
                seconds = 2 * (i - lastnotepos) / w.getframerate()
                # skip very short notes that are likely inaccuracies related to frequency changes
                if seconds > 0.1:
                    # quantify to ½ seconds resolution - small rounding errors are expected to result from chunked input data
                    roundedseconds = int(round(seconds * 2)) / 2
                    if roundedseconds < 0.5:
                        # FIXME: workaround for high pitches that appear shorter, not quite clear why
                        roundedseconds = 0.5
                    print(f"NOTE complete: {lastnote:3} [{lastnotepos:7}..{i-1:7}] = ~ {roundedseconds} s ({round(seconds, 2)}  s)")
                    noteslist.append((lastnote, roundedseconds))
            lastnote = note
            lastnotepos = i

if noteslist:
    f = open(wavfile + ".json", "w")
    json.dump(noteslist, f)
    f.close()
    print(f"Notes reproduced in {wavfile}.json.")
else:
    print("No notes found.")
